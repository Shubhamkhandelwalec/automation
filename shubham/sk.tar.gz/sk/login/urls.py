from django.urls import path
# from django.urls import re_path
from . import views

urlpatterns = [
    path('register/', views.Register, name='register'),
    path('login/', views.login, name='login'),
    path('user/dashboard/', views.dash , name='dashboard'),
    path('<int:update>',views.edit),
    path('del/<int:delid>', views.delete),
    path('register/verify/', views.get),
    path('user/verified',views.realregistration),
]