from django import forms
from .models import *


class Contact(forms.Form):
    name = forms.CharField(required=True)
    email = forms.EmailField(required=True)
    phone = forms.CharField(required=True)
    city = forms.CharField(required=True)

    class Meta:
        model = ContactUs
        fields = ('name', 'email', 'phone', 'city')
