from django.shortcuts import render
from .forms import *


def Home(request):
    if request.method == "POST":
        print(request.POST.get('name'))
        return render(request, 'index.html', {"msg": request.POST.get('name')})
        # form1 = Contact(request.POST, request.FILES)
        # if form1.is_valid():
        #     try:
        #         name = request.POST.get('name')
        #         email = request.POST.get('email')
        #         phone = request.POST.get('phone')
        #         city = request.POST.get('city')
        #         print(name, city, phone, email)
        #         database = ContactUs(name=name, email=email, phone_no=phone, city=city)
        #         database.save()
        #         return render(request, 'index.html', {"msg": "successfully inserted"})
        #     except Exception as e:
        #         print(e)
        #         return render(request, 'index.html', {"error": "jsklsdjflksjf"})
        # else:
        #     return render(request, 'index.html', {"form": form1})
    return render(request, 'index.html', {'msg': 'null'})
