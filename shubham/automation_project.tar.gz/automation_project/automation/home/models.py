from django.db import models


# Create your models here.
class ContactUs(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    is_email = models.BooleanField(default=False)
    phone_no = models.CharField(max_length=20)
    is_phone = models.BooleanField(default=False)
    city = models.CharField(max_length=200)
    currentdate = models.DateTimeField(auto_now_add=True)
