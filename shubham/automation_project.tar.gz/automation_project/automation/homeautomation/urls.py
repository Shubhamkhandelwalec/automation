from django.urls import path
from . import views

urlpatterns = [

    path('automation_kit/', views.Home_Automation_kit, name='Home automation kit'),



]