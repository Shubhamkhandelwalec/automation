from django.shortcuts import render

# Create your views here.
def Home_Automation_kit(request):
    return render(request,'home_automation_kit.html')